import streamlit as st
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

st.set_page_config(page_title="Iris Classifier AI Lab Project", layout="wide")

# Title
st.title("🌸 Iris Flower Classification - AI Lab Project")
st.markdown("### A Machine Learning Application with Explainable UI")

# Sidebar for navigation
menu = st.sidebar.selectbox("Navigate", ["Problem Setup", "Data Exploration", "Model Training", "Prediction", "Evaluation & Explanation"])

# Load data
@st.cache_data
def load_iris_data():
    iris = load_iris()
    df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
    df['species'] = iris.target
    df['species'] = df['species'].map({0: 'setosa', 1: 'versicolor', 2: 'virginica'})
    return df, iris.feature_names, iris.target_names

df, feature_names, target_names = load_iris_data()

if menu == "Problem Setup":
    st.header("Problem Setup")
    st.write("""
    **Input:** Measurements of iris flowers (sepal length, sepal width, petal length, petal width).
    **Output:** Predicted species (setosa, versicolor, virginica).
    **Constraints:** Features are positive real numbers.
    """)
    
    st.subheader("Upload or Use Sample Data")
    uploaded_file = st.file_uploader("Upload your own CSV (optional)", type="csv")
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.success("Data loaded successfully!")
    else:
        st.info("Using built-in Iris dataset.")
    
    st.dataframe(df.head())

elif menu == "Data Exploration":
    st.header("Data Exploration")
    st.write("Visual representations of the dataset.")
    
    col1, col2 = st.columns(2)
    with col1:
        fig = px.scatter(df, x='sepal length (cm)', y='sepal width (cm)', color='species', title="Sepal Dimensions")
        st.plotly_chart(fig)
    
    with col2:
        fig = px.scatter(df, x='petal length (cm)', y='petal width (cm)', color='species', title="Petal Dimensions")
        st.plotly_chart(fig)
    
    st.subheader("Pairplot")
    fig = sns.pairplot(df, hue='species')
    st.pyplot(fig)

elif menu == "Model Training":
    st.header("Model Training")
    st.write("Train a RandomForest Classifier.")
    
    test_size = st.slider("Test Size", 0.1, 0.5, 0.2)
    random_state = st.number_input("Random State", 42, value=42)
    
    X = df[feature_names]
    y = df['species']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
    
    if st.button("Train Model"):
        with st.spinner("Training..."):
            model = RandomForestClassifier(n_estimators=100, random_state=random_state)
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            acc = accuracy_score(y_test, y_pred)
            
            st.session_state.model = model
            st.session_state.acc = acc
            st.session_state.y_test = y_test
            st.session_state.y_pred = y_pred
            st.success(f"Model trained! Accuracy: {acc:.2f}")

elif menu == "Prediction":
    st.header("Make Predictions")
    if 'model' not in st.session_state:
        st.warning("Please train the model first in the Model Training section.")
    else:
        st.write("Enter flower measurements:")
        col1, col2 = st.columns(2)
        with col1:
            sl = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.0)
            sw = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.0)
        with col2:
            pl = st.slider("Petal Length (cm)", 1.0, 7.0, 4.0)
            pw = st.slider("Petal Width (cm)", 0.1, 2.5, 1.3)
        
        if st.button("Predict"):
            model = st.session_state.model
            input_data = np.array([[sl, sw, pl, pw]])
            pred = model.predict(input_data)[0]
            prob = model.predict_proba(input_data)[0]
            
            st.success(f"Predicted Species: **{pred}**")
            
            # Feature importance explanation
            st.subheader("Feature Contributions")
            importances = model.feature_importances_
            feat_imp = pd.DataFrame({'Feature': feature_names, 'Importance': importances})
            fig = px.bar(feat_imp, x='Feature', y='Importance', title="Feature Importances")
            st.plotly_chart(fig)
            
            st.write("**Explanation:** The prediction is based on learned patterns from training data. Petal measurements are most discriminative.")

elif menu == "Evaluation & Explanation":
    st.header("Evaluation and Explainability")
    if 'model' not in st.session_state:
        st.warning("Train model first.")
    else:
        acc = st.session_state.acc
        st.metric("Accuracy", f"{acc:.2f}")
        
        # Confusion Matrix
        cm = confusion_matrix(st.session_state.y_test, st.session_state.y_pred, labels=target_names)
        fig = px.imshow(cm, text_auto=True, labels=dict(x="Predicted", y="True", color="Count"),
                        x=target_names, y=target_names, title="Confusion Matrix")
        st.plotly_chart(fig)
        
        st.subheader("Classification Report")
        report = classification_report(st.session_state.y_test, st.session_state.y_pred, output_dict=True)
        st.dataframe(pd.DataFrame(report).transpose())
        
        st.subheader("Comparison")
        st.write("Baseline: Always predict most common class (versicolor).")
        baseline_acc = 1/3  # approx
        st.write(f"Model Accuracy: {acc:.2f} vs Baseline: {baseline_acc:.2f}")
        
        st.subheader("Natural Language Explanation")
        st.write("""
        The RandomForest model aggregates decisions from multiple decision trees. 
        It looks at feature thresholds (e.g., petal length > 2.5 cm often indicates non-setosa).
        This provides robustness and some interpretability via feature importances.
        """)

# Footer
st.sidebar.markdown("---")
st.sidebar.write("**Group Members:**")
st.sidebar.write("Hassan Akash - Roll: 2023/CSME/21")
st.sidebar.write("Hasnain Abbas - Roll: 2023/CSME/20")
st.sidebar.write("Sahil Hussain - Roll: 2023/CSME/42")
st.sidebar.write("Hasnain Hydar - Roll: 2023/CSME/22")

st.caption("AI Lab Project - UI + AI Integration")