# Short Report: Iris Classification Project

## Problem
Classify iris flowers into three species using four features.

## Method
- Data: scikit-learn Iris dataset
- Preprocessing: None needed (clean data)
- Model: RandomForestClassifier
- UI: Streamlit with Plotly visualizations

## AI Component
Machine Learning - Ensemble method for classification. Feature importances for explainability.

## Results
Achieves high accuracy. Visuals help understand feature distributions.

## Limitations & Improvements
- Limited to Iris data. Future: Add more datasets, deploy online, use advanced models like neural nets.